package com.example.wb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
